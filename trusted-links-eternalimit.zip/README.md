# 🔗 Trusted Links with Favicons — Eternalimit Edition

A minimalist HTML page that displays a list of trusted links, each with its favicon dynamically loaded via Google’s Favicon API.

## 🌐 Live Demo

[View Live](https://eternalimit.github.io/trusted-links/)

---

## ✨ Features

- ✅ Clean, responsive HTML/CSS layout
- 🌍 Dynamic favicons powered by Google
- 🔒 No JavaScript, no tracking, just HTML/CSS
- 📱 Mobile-friendly and lightweight

---

## 📁 Files

- `index.html`: Main page with styled trusted links
- `README.md`: This file
- Optional: `LICENSE`

---

## 🛠️ How to Use

1. Clone the repository:
   ```bash
   git clone https://github.com/eternalimit/trusted-links.git
   cd trusted-links
   ```

2. Open `index.html` in your browser:
   ```bash
   open index.html
   ```

3. To deploy with GitHub Pages:
   - Push to GitHub under the repository `eternalimit/trusted-links`
   - Enable GitHub Pages in repository settings
   - Visit: `https://eternalimit.github.io/trusted-links/`
