from fastapi import FastAPI, Request
from pydantic import BaseModel

class RegAuditGPT:
    def __init__(self):
        self.references = {
            "Title 22 CCR": {
                "97160": "Audit procedure requirements",
                "97199": "Notification timelines & facility obligations",
                "90001+": "Health Care Access & Information (HCAI) regulations"
            },
            "Title 24 CCR": {
                "General": "Hospital building standards and seismic safety"
            },
            "Health & Safety Code": {
                "1250+": "Statutory definitions and authority for hospital regulation"
            }
        }

    def match_text_to_regulations(self, text):
        matches = []
        for code, sections in self.references.items():
            for sec, desc in sections.items():
                if sec in text or code in text:
                    matches.append({"code": code, "section": sec, "description": desc})
        return matches

    def generate_summary_table(self, matches):
        table = "| Code | Section | Description |\n|------|---------|-------------|\n"
        for m in matches:
            table += f"| {m['code']} | {m['section']} | {m['description']} |\n"
        return table

    def analyze_input(self, text):
        findings = self.match_text_to_regulations(text)
        summary = self.generate_summary_table(findings)
        return {
            "raw_findings": findings,
            "summary_table": summary
        }

# Define FastAPI app
app = FastAPI()
reg_auditor = RegAuditGPT()

class AuditRequest(BaseModel):
    text: str

@app.post("/analyze")
async def analyze_text(data: AuditRequest):
    result = reg_auditor.analyze_input(data.text)
    return result

# Example to run:
# uvicorn this_file_name:app --reload --port 8000
